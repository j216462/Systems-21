**DEPRECATED**
Please use new version of library:
https://github.com/adafruit/Adafruit_CircuitPython_BNO055

# Adafruit Python BNO055

Library for accessing the Bosch BNO055 absolute orientation sensor on a Raspberry Pi or Beaglebone Black.
